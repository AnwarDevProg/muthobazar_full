# MuthoBazar Home Full-Width Card Layout Fix

## Problem

Admin save is correct. The debug files show:
- horizontal03 selectedIsFullWidth = true
- wide04 selectedIsFullWidth = true

But Home showed those cards inside half-width product cells.

## Root cause

`MBHomeProductGridSection` used `GridView.builder`, and a normal 2-column
GridView gives every item the same half-width slot. A full-width card cannot
span two columns inside that layout.

## Fix

This patch replaces the grid section layout with a card-aware flow:

- full-width variants: full row
- half-width variants: two per row
- full MBProduct still goes to MBProductCardRenderer
- cardConfig settings still work

## Apply

Extract into repo root:

C:\Users\1\AndroidStudioProjects\MuthoBazar

Run:

powershell -ExecutionPolicy Bypass -File .\tools\patch_home_full_width_card_layout.ps1
flutter analyze

Then full restart customer app and pull-refresh Home.
