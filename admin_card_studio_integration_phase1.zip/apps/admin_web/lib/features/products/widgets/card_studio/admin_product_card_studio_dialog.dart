import 'package:flutter/material.dart';
import 'package:shared_models/shared_models.dart';
import 'package:shared_ui/widgets/common/product_cards/mb_product_card_renderer.dart';
import 'package:shared_ui/widgets/common/product_cards/system/mb_card_config_resolver.dart';

// File: admin_product_card_studio_dialog.dart
// Suggested location:
// apps/admin_web/lib/features/products/widgets/card_studio/admin_product_card_studio_dialog.dart
//
// Purpose:
// Product-card selection + configuration studio for Admin Product Create/Edit.
//
// Design behavior:
// - Opens from the product dialog after clicking "Select card".
// - Left panel switches between card variant selection and supported settings.
// - Right panel stays alive the whole time and shows a medium mobile-screen
//   preview of only the selected card.
// - Preview uses live product form data through previewProductBuilder.
// - Card selection/config state remains local until the admin clicks Apply.
//
// Integration rule:
// Product form should pass a previewProductBuilder that builds MBProduct from
// the current unsaved form values and applies the supplied MBCardInstanceConfig.
// This dialog should not write to Firestore directly.

typedef AdminProductCardPreviewBuilder = MBProduct Function(
  MBCardInstanceConfig cardConfig,
);

class AdminProductCardStudioResult {
  const AdminProductCardStudioResult({
    required this.cardConfig,
    required this.variant,
    required this.family,
  });

  final MBCardInstanceConfig cardConfig;
  final MBCardVariant variant;
  final MBCardFamily family;

  String get variantId => variant.id;
  String get familyId => family.id;
}

enum AdminProductCardStudioMode {
  select,
  configure,
}

class AdminProductCardStudioDialog extends StatefulWidget {
  const AdminProductCardStudioDialog({
    super.key,
    required this.previewProductBuilder,
    this.initialConfig,
    this.availableVariants,
    this.initialMode = AdminProductCardStudioMode.select,
    this.title = 'Customer App Card Studio',
    this.subtitle =
        'Pick a product card, then tune its settings with live mobile preview.',
  });

  final AdminProductCardPreviewBuilder previewProductBuilder;
  final MBCardInstanceConfig? initialConfig;
  final List<MBCardVariant>? availableVariants;
  final AdminProductCardStudioMode initialMode;
  final String title;
  final String subtitle;

  static Future<AdminProductCardStudioResult?> show(
    BuildContext context, {
    required AdminProductCardPreviewBuilder previewProductBuilder,
    MBCardInstanceConfig? initialConfig,
    List<MBCardVariant>? availableVariants,
    AdminProductCardStudioMode initialMode = AdminProductCardStudioMode.select,
  }) {
    return showDialog<AdminProductCardStudioResult>(
      context: context,
      barrierDismissible: false,
      builder: (_) {
        return AdminProductCardStudioDialog(
          previewProductBuilder: previewProductBuilder,
          initialConfig: initialConfig,
          availableVariants: availableVariants,
          initialMode: initialMode,
        );
      },
    );
  }

  @override
  State<AdminProductCardStudioDialog> createState() =>
      _AdminProductCardStudioDialogState();
}

class _AdminProductCardStudioDialogState
    extends State<AdminProductCardStudioDialog> {
  late MBCardVariant _selectedVariant;
  late MBCardInstanceConfig _draftConfig;
  late AdminProductCardStudioMode _mode;

  bool _variantWasPicked = false;
  String _familyFilter = 'all';
  String _searchText = '';

  @override
  void initState() {
    super.initState();

    final initial = widget.initialConfig?.normalized();
    _selectedVariant = initial?.variant ?? MBCardVariant.compact01;
    _draftConfig = initial ??
        MBCardInstanceConfig(
          family: _selectedVariant.family,
          variant: _selectedVariant,
          settings: _defaultSettingsFor(_selectedVariant),
        );

    _mode = widget.initialMode;
    _variantWasPicked = widget.initialConfig != null;
  }

  @override
  Widget build(BuildContext context) {
    final product = widget.previewProductBuilder(_draftConfig);

    return Dialog(
      insetPadding: const EdgeInsets.symmetric(horizontal: 28, vertical: 24),
      backgroundColor: Colors.transparent,
      child: ConstrainedBox(
        constraints: const BoxConstraints(
          maxWidth: 1280,
          maxHeight: 820,
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(28),
          child: Material(
            color: const Color(0xFFF8FAFC),
            child: Column(
              children: [
                _buildHeader(context),
                const Divider(height: 1),
                Expanded(
                  child: Row(
                    children: [
                      Expanded(
                        flex: 11,
                        child: _buildLeftPanel(context),
                      ),
                      const VerticalDivider(width: 1),
                      Expanded(
                        flex: 8,
                        child: _AdminProductCardLivePreviewPanel(
                          product: product,
                          cardConfig: _draftConfig,
                          variant: _selectedVariant,
                        ),
                      ),
                    ],
                  ),
                ),
                const Divider(height: 1),
                _buildFooter(context),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      color: Colors.white,
      padding: const EdgeInsets.fromLTRB(22, 18, 18, 16),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: const Color(0xFFFFF3EA),
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Icon(
              Icons.view_carousel_rounded,
              color: Color(0xFFF97316),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: theme.textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w900,
                    color: const Color(0xFF111827),
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  widget.subtitle,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: const Color(0xFF6B7280),
                    height: 1.25,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 16),
          _buildModeSegment(context),
          const SizedBox(width: 12),
          IconButton(
            tooltip: 'Close',
            onPressed: () => Navigator.of(context).pop(),
            icon: const Icon(Icons.close_rounded),
          ),
        ],
      ),
    );
  }

  Widget _buildModeSegment(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF3EA),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: const Color(0xFFFED7AA)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _modeButton(
            context,
            label: 'Select',
            icon: Icons.dashboard_customize_rounded,
            selected: _mode == AdminProductCardStudioMode.select,
            onTap: () => setState(
              () => _mode = AdminProductCardStudioMode.select,
            ),
          ),
          _modeButton(
            context,
            label: 'Configure',
            icon: Icons.tune_rounded,
            selected: _mode == AdminProductCardStudioMode.configure,
            onTap: () => setState(
              () => _mode = AdminProductCardStudioMode.configure,
            ),
          ),
        ],
      ),
    );
  }

  Widget _modeButton(
    BuildContext context, {
    required String label,
    required IconData icon,
    required bool selected,
    required VoidCallback onTap,
  }) {
    return InkWell(
      borderRadius: BorderRadius.circular(999),
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFFF97316) : Colors.transparent,
          borderRadius: BorderRadius.circular(999),
        ),
        child: Row(
          children: [
            Icon(
              icon,
              size: 16,
              color: selected ? Colors.white : const Color(0xFF9A3412),
            ),
            const SizedBox(width: 6),
            Text(
              label,
              style: Theme.of(context).textTheme.labelMedium?.copyWith(
                    color: selected ? Colors.white : const Color(0xFF9A3412),
                    fontWeight: FontWeight.w900,
                  ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLeftPanel(BuildContext context) {
    switch (_mode) {
      case AdminProductCardStudioMode.select:
        return _buildVariantBrowser(context);
      case AdminProductCardStudioMode.configure:
        return _buildSettingsPanel(context);
    }
  }

  Widget _buildVariantBrowser(BuildContext context) {
    final variants = _filteredVariants();
    final grouped = <MBCardFamily, List<MBCardVariant>>{};

    for (final variant in variants) {
      grouped.putIfAbsent(variant.family, () => <MBCardVariant>[]).add(variant);
    }

    return Container(
      color: const Color(0xFFF8FAFC),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildBrowserToolbar(context),
          const Divider(height: 1),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
              children: [
                for (final entry in grouped.entries) ...[
                  _familyHeader(context, entry.key),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 12,
                    runSpacing: 12,
                    children: [
                      for (final variant in entry.value)
                        _variantTile(context, variant),
                    ],
                  ),
                  const SizedBox(height: 24),
                ],
                if (grouped.isEmpty)
                  const _EmptyStateCard(
                    title: 'No card variant found',
                    subtitle: 'Try another family filter or search keyword.',
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBrowserToolbar(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 16, 18, 14),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: TextField(
                  onChanged: (value) {
                    setState(() => _searchText = value.trim().toLowerCase());
                  },
                  decoration: InputDecoration(
                    isDense: true,
                    prefixIcon: const Icon(Icons.search_rounded),
                    hintText: 'Search card family or variant...',
                    filled: true,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: const BorderSide(color: Color(0xFFE5E7EB)),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              _selectedSummaryChip(context),
            ],
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 38,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                _familyFilterChip(context, id: 'all', label: 'All'),
                for (final family in _familiesForFilter())
                  _familyFilterChip(
                    context,
                    id: family.id,
                    label: family.label,
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _selectedSummaryChip(BuildContext context) {
    final definition = _safeDefinition(_selectedVariant);

    return Container(
      constraints: const BoxConstraints(maxWidth: 260),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF7ED),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: const Color(0xFFFED7AA)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(
            Icons.check_circle_rounded,
            size: 16,
            color: Color(0xFFF97316),
          ),
          const SizedBox(width: 7),
          Flexible(
            child: Text(
              '${_selectedVariant.id} · ${definition.footprint.label}',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: Theme.of(context).textTheme.labelMedium?.copyWith(
                    color: const Color(0xFF9A3412),
                    fontWeight: FontWeight.w900,
                  ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _familyFilterChip(
    BuildContext context, {
    required String id,
    required String label,
  }) {
    final selected = _familyFilter == id;

    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(
        label: Text(label),
        selected: selected,
        onSelected: (_) => setState(() => _familyFilter = id),
        labelStyle: Theme.of(context).textTheme.labelMedium?.copyWith(
              color: selected ? Colors.white : const Color(0xFF374151),
              fontWeight: FontWeight.w800,
            ),
        selectedColor: const Color(0xFFF97316),
        backgroundColor: Colors.white,
        side: BorderSide(
          color: selected ? const Color(0xFFF97316) : const Color(0xFFE5E7EB),
        ),
      ),
    );
  }

  Widget _familyHeader(BuildContext context, MBCardFamily family) {
    final description = _familyDescription(family);

    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Text(
          family.label,
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w900,
                color: const Color(0xFF111827),
              ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Text(
            description,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: const Color(0xFF6B7280),
                ),
          ),
        ),
      ],
    );
  }

  Widget _variantTile(BuildContext context, MBCardVariant variant) {
    final selected = variant == _selectedVariant;
    final definition = _safeDefinition(variant);

    return InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap: () => _selectVariant(variant),
      child: AnimatedContainer(
        width: 250,
        duration: const Duration(milliseconds: 160),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFFFFF7ED) : Colors.white,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(
            width: selected ? 2 : 1,
            color: selected ? const Color(0xFFF97316) : const Color(0xFFE5E7EB),
          ),
          boxShadow: [
            if (selected)
              BoxShadow(
                color: const Color(0xFFF97316).withValues(alpha: 0.12),
                blurRadius: 18,
                offset: const Offset(0, 8),
              ),
          ],
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _variantMiniPreviewMark(variant),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    variant.id,
                    style: Theme.of(context).textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.w900,
                          color: const Color(0xFF111827),
                        ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    _variantDescription(variant),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: const Color(0xFF6B7280),
                          height: 1.25,
                        ),
                  ),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: [
                      _tinyChip(context, variant.family.label),
                      _tinyChip(context, definition.footprint.label),
                      if (definition.supportsAnyCustomization)
                        _tinyChip(context, 'config'),
                    ],
                  ),
                ],
              ),
            ),
            if (selected)
              const Icon(
                Icons.check_circle_rounded,
                color: Color(0xFFF97316),
                size: 20,
              ),
          ],
        ),
      ),
    );
  }

  Widget _variantMiniPreviewMark(MBCardVariant variant) {
    final color = _familyColor(variant.family);

    return Container(
      width: 46,
      height: 58,
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.14),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withValues(alpha: 0.35)),
      ),
      child: Stack(
        children: [
          Positioned(
            top: 7,
            left: 7,
            right: 7,
            height: 12,
            child: DecoratedBox(
              decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(999),
              ),
            ),
          ),
          Positioned(
            left: 10,
            right: 10,
            top: 24,
            height: variant.isFullWidth ? 16 : 22,
            child: DecoratedBox(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(999),
                border: Border.all(color: color.withValues(alpha: 0.35)),
              ),
            ),
          ),
          Positioned(
            left: 8,
            right: 8,
            bottom: 8,
            height: 6,
            child: DecoratedBox(
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.55),
                borderRadius: BorderRadius.circular(999),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSettingsPanel(BuildContext context) {
    final definition = _safeDefinition(_selectedVariant);
    final supported = definition.supportedSettings;

    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
      children: [
        _sectionTitle(
          context,
          title: 'Configure ${_selectedVariant.id}',
          subtitle:
              'Only settings supported by this variant should be exposed here.',
        ),
        const SizedBox(height: 16),
        if (supported.canChangeSurface) _surfaceControls(context),
        if (supported.canChangeTypography) _typographyControls(context),
        if (supported.canChangeMedia) _mediaControls(context),
        if (supported.canChangePrice) _priceControls(context),
        if (supported.canChangeActions) _actionControls(context),
        if (supported.canChangeAccent || supported.canChangeMedia)
          _backgroundControls(context),
        if (supported.canChangeBorderEffect) _borderControls(context),
        if (!supported.supportsAnyCustomization)
          const _EmptyStateCard(
            title: 'This variant is locked',
            subtitle:
                'The selected card does not expose custom settings yet. You can still select it.',
          ),
      ],
    );
  }

  Widget _surfaceControls(BuildContext context) {
    final surface = _draftConfig.settings.surface ??
        const MBCardSurfaceSettings(
          borderRadius: 18,
          elevationLevel: 2,
          paddingScale: 1,
        );

    return _settingsCard(
      context,
      title: 'Surface',
      icon: Icons.layers_rounded,
      children: [
        _slider(
          context,
          label: 'Corner radius',
          value: surface.borderRadius,
          min: 0,
          max: 32,
          divisions: 32,
          onChanged: (value) => _updateSettings(
            _draftConfig.settings.copyWith(
              surface: surface.copyWith(borderRadius: value),
            ),
          ),
        ),
        _slider(
          context,
          label: 'Shadow / elevation',
          value: surface.elevationLevel,
          min: 0,
          max: 8,
          divisions: 8,
          onChanged: (value) => _updateSettings(
            _draftConfig.settings.copyWith(
              surface: surface.copyWith(
                elevationLevel: value,
                showShadow: value > 0,
              ),
            ),
          ),
        ),
        _slider(
          context,
          label: 'Padding scale',
          value: surface.paddingScale,
          min: 0.75,
          max: 1.25,
          divisions: 10,
          onChanged: (value) => _updateSettings(
            _draftConfig.settings.copyWith(
              surface: surface.copyWith(paddingScale: value),
            ),
          ),
        ),
      ],
    );
  }

  Widget _typographyControls(BuildContext context) {
    final typography = _draftConfig.settings.typography ??
        const MBCardTypographySettings(
          titleMaxLines: 2,
          subtitleMaxLines: 2,
          titleFontSize: 14.5,
          titleMinFontSize: 11,
          subtitleFontSize: 11.5,
          priceFontSize: 18,
          oldPriceFontSize: 12,
          titleAutoShrink: true,
        );

    return _settingsCard(
      context,
      title: 'Typography',
      icon: Icons.text_fields_rounded,
      children: [
        _slider(
          context,
          label: 'Title font size',
          value: typography.titleFontSize ?? 14.5,
          min: 11,
          max: 19,
          divisions: 16,
          onChanged: (value) => _updateSettings(
            _draftConfig.settings.copyWith(
              typography: typography.copyWith(titleFontSize: value),
            ),
          ),
        ),
        _slider(
          context,
          label: 'Title min font size',
          value: typography.titleMinFontSize,
          min: 9,
          max: 14,
          divisions: 10,
          onChanged: (value) => _updateSettings(
            _draftConfig.settings.copyWith(
              typography: typography.copyWith(titleMinFontSize: value),
            ),
          ),
        ),
        _slider(
          context,
          label: 'Subtitle font size',
          value: typography.subtitleFontSize ?? 11.5,
          min: 9,
          max: 15,
          divisions: 12,
          onChanged: (value) => _updateSettings(
            _draftConfig.settings.copyWith(
              typography: typography.copyWith(subtitleFontSize: value),
            ),
          ),
        ),
        _slider(
          context,
          label: 'Final price font size',
          value: typography.priceFontSize ?? 18,
          min: 14,
          max: 24,
          divisions: 10,
          onChanged: (value) => _updateSettings(
            _draftConfig.settings.copyWith(
              typography: typography.copyWith(priceFontSize: value),
            ),
          ),
        ),
      ],
    );
  }

  Widget _mediaControls(BuildContext context) {
    final media = _draftConfig.settings.media ??
        const MBCardMediaSettings(
          imageShape: 'circle',
          imageSizeRatio: 0.72,
          imageTopRatio: 0.305,
          imageRingThickness: 8,
          imageFitMode: 'cover',
          showImageShadow: true,
        );

    return _settingsCard(
      context,
      title: 'Media',
      icon: Icons.image_rounded,
      children: [
        _slider(
          context,
          label: 'Image size ratio',
          value: media.imageSizeRatio ?? 0.72,
          min: 0.55,
          max: 0.88,
          divisions: 33,
          onChanged: (value) => _updateSettings(
            _draftConfig.settings.copyWith(
              media: media.copyWith(imageSizeRatio: value),
            ),
          ),
        ),
        _slider(
          context,
          label: 'Image top ratio',
          value: media.imageTopRatio ?? 0.305,
          min: 0.20,
          max: 0.42,
          divisions: 22,
          onChanged: (value) => _updateSettings(
            _draftConfig.settings.copyWith(
              media: media.copyWith(imageTopRatio: value),
            ),
          ),
        ),
        _slider(
          context,
          label: 'Image ring thickness',
          value: media.imageRingThickness ?? 8,
          min: 0,
          max: 16,
          divisions: 16,
          onChanged: (value) => _updateSettings(
            _draftConfig.settings.copyWith(
              media: media.copyWith(imageRingThickness: value),
            ),
          ),
        ),
        SwitchListTile.adaptive(
          contentPadding: EdgeInsets.zero,
          title: const Text('Image shadow'),
          value: media.showImageShadow,
          onChanged: (value) => _updateSettings(
            _draftConfig.settings.copyWith(
              media: media.copyWith(showImageShadow: value),
            ),
          ),
        ),
      ],
    );
  }

  Widget _priceControls(BuildContext context) {
    final price = _draftConfig.settings.price ??
        const MBCardPriceSettings(
          priceMode: MBCardPriceMode.originalAndFinal,
          showSavingsText: true,
          showDiscountBadge: true,
          savingsDisplayMode: 'percent',
        );

    return _settingsCard(
      context,
      title: 'Price / Sale',
      icon: Icons.payments_rounded,
      children: [
        SwitchListTile.adaptive(
          contentPadding: EdgeInsets.zero,
          title: const Text('Show original price when sale active'),
          value: price.showOriginalPriceWhenSaleActive,
          onChanged: (value) => _updateSettings(
            _draftConfig.settings.copyWith(
              price: price.copyWith(showOriginalPriceWhenSaleActive: value),
            ),
          ),
        ),
        SwitchListTile.adaptive(
          contentPadding: EdgeInsets.zero,
          title: const Text('Show savings chip'),
          value: price.showSavingsText,
          onChanged: (value) => _updateSettings(
            _draftConfig.settings.copyWith(
              price: price.copyWith(showSavingsText: value),
            ),
          ),
        ),
        _dropdown(
          context,
          label: 'Savings display mode',
          value: price.savingsDisplayMode,
          values: const ['percent', 'amount', 'both'],
          onChanged: (value) => _updateSettings(
            _draftConfig.settings.copyWith(
              price: price.copyWith(savingsDisplayMode: value),
            ),
          ),
        ),
      ],
    );
  }

  Widget _actionControls(BuildContext context) {
    final actions = _draftConfig.settings.actions ??
        const MBCardActionSettings(
          showAddToCart: true,
          showBuyNow: true,
          ctaText: 'Buy',
        );

    return _settingsCard(
      context,
      title: 'Action',
      icon: Icons.touch_app_rounded,
      children: [
        SwitchListTile.adaptive(
          contentPadding: EdgeInsets.zero,
          title: const Text('Show Buy button'),
          value: actions.showAddToCart || actions.showBuyNow,
          onChanged: (value) => _updateSettings(
            _draftConfig.settings.copyWith(
              actions: actions.copyWith(
                showAddToCart: value,
                showBuyNow: value,
              ),
            ),
          ),
        ),
        _dropdown(
          context,
          label: 'Button text',
          value: actions.ctaText?.trim().isNotEmpty == true
              ? actions.ctaText!
              : 'Buy',
          values: const ['Buy', 'Add', 'Order', 'View'],
          onChanged: (value) => _updateSettings(
            _draftConfig.settings.copyWith(
              actions: actions.copyWith(ctaText: value),
            ),
          ),
        ),
      ],
    );
  }

  Widget _backgroundControls(BuildContext context) {
    final background = _draftConfig.settings.background ??
        const MBCardBackgroundSettings(
          showTopPanel: true,
          panelShape: 'diagonal',
          diagonalStartRatio: 0.58,
          diagonalEndRatio: 0.38,
          panelHeightRatio: 0.46,
        );

    return _settingsCard(
      context,
      title: 'Background / Diagonal Panel',
      icon: Icons.gradient_rounded,
      children: [
        _slider(
          context,
          label: 'Left diagonal depth',
          value: background.diagonalStartRatio ?? 0.58,
          min: 0.42,
          max: 0.72,
          divisions: 30,
          onChanged: (value) => _updateSettings(
            _draftConfig.settings.copyWith(
              background: background.copyWith(diagonalStartRatio: value),
            ),
          ),
        ),
        _slider(
          context,
          label: 'Right diagonal depth',
          value: background.diagonalEndRatio ?? 0.38,
          min: 0.22,
          max: 0.56,
          divisions: 34,
          onChanged: (value) => _updateSettings(
            _draftConfig.settings.copyWith(
              background: background.copyWith(diagonalEndRatio: value),
            ),
          ),
        ),
        _slider(
          context,
          label: 'Curve control',
          value: background.panelHeightRatio ?? 0.46,
          min: 0.30,
          max: 0.62,
          divisions: 32,
          onChanged: (value) => _updateSettings(
            _draftConfig.settings.copyWith(
              background: background.copyWith(panelHeightRatio: value),
            ),
          ),
        ),
      ],
    );
  }

  Widget _borderControls(BuildContext context) {
    final border = _draftConfig.settings.borderEffect ??
        const MBCardBorderEffectSettings(
          showBorder: false,
          effectPreset: 'none',
          effectIntensity: 0,
        );

    return _settingsCard(
      context,
      title: 'Border / Effect',
      icon: Icons.auto_awesome_rounded,
      children: [
        SwitchListTile.adaptive(
          contentPadding: EdgeInsets.zero,
          title: const Text('Show outer line'),
          value: border.showBorder,
          onChanged: (value) => _updateSettings(
            _draftConfig.settings.copyWith(
              borderEffect: border.copyWith(showBorder: value),
            ),
          ),
        ),
        _dropdown(
          context,
          label: 'Effect preset',
          value: border.effectPreset,
          values: const ['none', 'simple', 'soft_glow', 'wave', 'electric'],
          onChanged: (value) => _updateSettings(
            _draftConfig.settings.copyWith(
              borderEffect: border.copyWith(effectPreset: value),
            ),
          ),
        ),
        _slider(
          context,
          label: 'Effect intensity',
          value: border.effectIntensity,
          min: 0,
          max: 1,
          divisions: 10,
          onChanged: (value) => _updateSettings(
            _draftConfig.settings.copyWith(
              borderEffect: border.copyWith(effectIntensity: value),
            ),
          ),
        ),
      ],
    );
  }

  Widget _settingsCard(
    BuildContext context, {
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0xFFE5E7EB)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 18, color: const Color(0xFFF97316)),
              const SizedBox(width: 8),
              Text(
                title,
                style: Theme.of(context).textTheme.titleSmall?.copyWith(
                      fontWeight: FontWeight.w900,
                    ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ...children,
        ],
      ),
    );
  }

  Widget _slider(
    BuildContext context, {
    required String label,
    required double value,
    required double min,
    required double max,
    required ValueChanged<double> onChanged,
    int? divisions,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '$label: ${value.toStringAsFixed(2)}',
          style: Theme.of(context).textTheme.labelMedium?.copyWith(
                fontWeight: FontWeight.w800,
              ),
        ),
        Slider(
          value: value.clamp(min, max),
          min: min,
          max: max,
          divisions: divisions,
          label: value.toStringAsFixed(2),
          onChanged: onChanged,
        ),
      ],
    );
  }

  Widget _dropdown(
    BuildContext context, {
    required String label,
    required String value,
    required List<String> values,
    required ValueChanged<String> onChanged,
  }) {
    final safeValue = values.contains(value) ? value : values.first;

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: DropdownButtonFormField<String>(
        value: safeValue,
        decoration: InputDecoration(
          labelText: label,
          isDense: true,
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
          ),
        ),
        items: [
          for (final item in values)
            DropdownMenuItem<String>(
              value: item,
              child: Text(item),
            ),
        ],
        onChanged: (next) {
          if (next == null) return;
          onChanged(next);
        },
      ),
    );
  }

  Widget _sectionTitle(
    BuildContext context, {
    required String title,
    required String subtitle,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w900,
                color: const Color(0xFF111827),
              ),
        ),
        const SizedBox(height: 5),
        Text(
          subtitle,
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: const Color(0xFF6B7280),
                height: 1.30,
              ),
        ),
      ],
    );
  }

  Widget _tinyChip(BuildContext context, String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(
        color: const Color(0xFFF3F4F6),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        label,
        style: Theme.of(context).textTheme.labelSmall?.copyWith(
              fontWeight: FontWeight.w800,
              color: const Color(0xFF374151),
            ),
      ),
    );
  }

  Widget _buildFooter(BuildContext context) {
    final canSelect = _variantWasPicked;

    return Container(
      color: Colors.white,
      padding: const EdgeInsets.fromLTRB(18, 12, 18, 12),
      child: Row(
        children: [
          Expanded(
            child: Text(
              canSelect
                  ? 'Selected: ${_selectedVariant.id} · ${_selectedVariant.family.label}'
                  : 'Pick a variant to enable Select card.',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: const Color(0xFF6B7280),
                    fontWeight: FontWeight.w700,
                  ),
            ),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          const SizedBox(width: 8),
          OutlinedButton.icon(
            onPressed: canSelect
                ? () => setState(
                      () => _mode = AdminProductCardStudioMode.configure,
                    )
                : null,
            icon: const Icon(Icons.tune_rounded),
            label: const Text('Edit card'),
          ),
          const SizedBox(width: 8),
          FilledButton.icon(
            onPressed: canSelect ? _applySelection : null,
            icon: const Icon(Icons.check_rounded),
            label: const Text('Select card'),
            style: FilledButton.styleFrom(
              backgroundColor: const Color(0xFFF97316),
              foregroundColor: Colors.white,
            ),
          ),
        ],
      ),
    );
  }

  void _selectVariant(MBCardVariant variant) {
    final oldSettings = _draftConfig.settings;
    final defaultSettings = _defaultSettingsFor(variant);

    setState(() {
      _selectedVariant = variant;
      _variantWasPicked = true;
      _draftConfig = MBCardInstanceConfig(
        family: variant.family,
        variant: variant,
        presetId: _draftConfig.presetId,
        settings: oldSettings.isNotEmpty ? oldSettings : defaultSettings,
      ).normalized();
    });
  }

  void _updateSettings(MBCardSettingsOverride settings) {
    setState(() {
      _draftConfig = MBCardInstanceConfig(
        family: _selectedVariant.family,
        variant: _selectedVariant,
        presetId: _draftConfig.presetId,
        settings: settings,
      ).normalized();
    });
  }

  void _applySelection() {
    Navigator.of(context).pop(
      AdminProductCardStudioResult(
        cardConfig: _draftConfig.normalized(),
        variant: _selectedVariant,
        family: _selectedVariant.family,
      ),
    );
  }

  List<MBCardVariant> _allVariants() {
    final source = widget.availableVariants ?? MBCardVariant.values;
    return source.toList(growable: false);
  }

  List<MBCardVariant> _filteredVariants() {
    final query = _searchText.trim().toLowerCase();

    return _allVariants().where((variant) {
      final familyMatches =
          _familyFilter == 'all' || variant.family.id == _familyFilter;

      if (!familyMatches) return false;
      if (query.isEmpty) return true;

      return variant.id.toLowerCase().contains(query) ||
          variant.family.id.toLowerCase().contains(query) ||
          variant.family.label.toLowerCase().contains(query);
    }).toList(growable: false);
  }

  List<MBCardFamily> _familiesForFilter() {
    final families = <MBCardFamily>{};

    for (final variant in _allVariants()) {
      families.add(variant.family);
    }

    final result = families.toList()
      ..sort((a, b) => a.label.compareTo(b.label));

    return result;
  }

  MBCardVariantDefinition _safeDefinition(MBCardVariant variant) {
    try {
      return MBCardConfigResolver.definitionForVariant(variant);
    } catch (_) {
      return MBCardVariantDefinition(
        variant: variant,
        family: variant.family,
        footprint: variant.isFullWidth
            ? MBCardFootprint.fullWidth
            : MBCardFootprint.halfWidth,
      );
    }
  }

  MBCardSettingsOverride _defaultSettingsFor(MBCardVariant variant) {
    if (variant == MBCardVariant.compact01) {
      return const MBCardSettingsOverride(
        surface: MBCardSurfaceSettings(
          borderRadius: 18,
          elevationLevel: 2,
          paddingScale: 1,
          showShadow: true,
        ),
        typography: MBCardTypographySettings(
          titleMaxLines: 2,
          subtitleMaxLines: 2,
          titleFontSize: 14.5,
          titleMinFontSize: 11,
          subtitleFontSize: 11.5,
          priceFontSize: 18,
          oldPriceFontSize: 12,
          titleAutoShrink: true,
          italicTitle: true,
          italicSubtitle: true,
        ),
        media: MBCardMediaSettings(
          imageShape: 'circle',
          imageFitMode: 'cover',
          imageSizeRatio: 0.72,
          imageTopRatio: 0.305,
          imageRingThickness: 8,
          showImageShadow: true,
        ),
        price: MBCardPriceSettings(
          priceMode: MBCardPriceMode.originalAndFinal,
          showDiscountBadge: true,
          showSavingsText: true,
          showOriginalPriceWhenSaleActive: true,
          savingsDisplayMode: 'percent',
          emphasizeFinalPrice: true,
          showCurrencySymbol: true,
        ),
        actions: MBCardActionSettings(
          showAddToCart: true,
          showBuyNow: true,
          ctaText: 'Buy',
          ctaStylePreset: 'cta_strong_pill',
          ctaColorToken: 'cta_orange',
        ),
        background: MBCardBackgroundSettings(
          showTopPanel: true,
          panelShape: 'diagonal',
          diagonalStartRatio: 0.58,
          diagonalEndRatio: 0.38,
          panelHeightRatio: 0.46,
        ),
      );
    }

    return MBCardSettingsOverride(
      actions: const MBCardActionSettings(
        showAddToCart: true,
        ctaText: 'Buy',
      ),
      price: const MBCardPriceSettings(
        priceMode: MBCardPriceMode.originalAndFinal,
        showCurrencySymbol: true,
      ),
      surface: const MBCardSurfaceSettings(
        borderRadius: 18,
        elevationLevel: 2,
      ),
      media: MBCardMediaSettings(
        imageShape: variant.isFullWidth ? 'rounded' : 'circle',
        imageFitMode: 'cover',
      ),
    );
  }

  String _familyDescription(MBCardFamily family) {
    switch (family) {
      case MBCardFamily.compact:
        return 'Dense everyday browse cards for two-column product grids.';
      case MBCardFamily.price:
        return 'Deal-first cards where final price and discount are strongest.';
      case MBCardFamily.horizontal:
        return 'Full-width row cards for fast scanning and comparison.';
      case MBCardFamily.premium:
        return 'Cleaner cards with more refined brand presentation.';
      case MBCardFamily.wide:
        return 'Image-led full-width product showcase cards.';
      case MBCardFamily.featured:
        return 'Hero-like section anchors for strong focus products.';
      case MBCardFamily.promo:
        return 'Campaign-aware cards for seasonal or curated promotion.';
      case MBCardFamily.flashSale:
        return 'Urgency-driven cards for stock/time pressure.';
      case MBCardFamily.combo:
        return 'Future combo-product layout family.';
      case MBCardFamily.variant:
        return 'Future variant-led card family.';
      case MBCardFamily.minimal:
        return 'Future minimal product card family.';
      case MBCardFamily.infoRich:
        return 'Future metadata-heavy product card family.';
    }
  }

  String _variantDescription(MBCardVariant variant) {
    switch (variant.family) {
      case MBCardFamily.compact:
        return variant == MBCardVariant.compact01
            ? 'Reference diagonal card with circular media, save chip, bottom price row, and Buy CTA.'
            : 'Compact-grid variant reserved for future customer browsing styles.';
      case MBCardFamily.price:
        return 'Price and discount focused conversion card.';
      case MBCardFamily.horizontal:
        return 'Row-style card that can occupy full mobile width.';
      case MBCardFamily.premium:
        return 'Premium-looking product presentation card.';
      case MBCardFamily.wide:
        return 'Full-width visual emphasis product card.';
      case MBCardFamily.featured:
        return 'Large section-anchor product card.';
      case MBCardFamily.promo:
        return 'Campaign/product hybrid presentation card.';
      case MBCardFamily.flashSale:
        return 'Urgency-led sale card.';
      case MBCardFamily.combo:
      case MBCardFamily.variant:
      case MBCardFamily.minimal:
      case MBCardFamily.infoRich:
        return 'Extended future product-card variant.';
    }
  }

  Color _familyColor(MBCardFamily family) {
    switch (family) {
      case MBCardFamily.compact:
        return const Color(0xFFF97316);
      case MBCardFamily.price:
        return const Color(0xFFDC2626);
      case MBCardFamily.horizontal:
        return const Color(0xFF2563EB);
      case MBCardFamily.premium:
        return const Color(0xFF7C3AED);
      case MBCardFamily.wide:
        return const Color(0xFF0891B2);
      case MBCardFamily.featured:
        return const Color(0xFFCA8A04);
      case MBCardFamily.promo:
        return const Color(0xFFDB2777);
      case MBCardFamily.flashSale:
        return const Color(0xFFEA580C);
      case MBCardFamily.combo:
      case MBCardFamily.variant:
      case MBCardFamily.minimal:
      case MBCardFamily.infoRich:
        return const Color(0xFF4B5563);
    }
  }
}

class _AdminProductCardLivePreviewPanel extends StatelessWidget {
  const _AdminProductCardLivePreviewPanel({
    required this.product,
    required this.cardConfig,
    required this.variant,
  });

  final MBProduct product;
  final MBCardInstanceConfig cardConfig;
  final MBCardVariant variant;

  @override
  Widget build(BuildContext context) {
    final resolved = MBCardConfigResolver.resolve(cardConfig);
    final footprint = resolved.footprint;
    final cardWidth = _cardWidthForFootprint(footprint);
    final previewContext = footprint.isFullWidth
        ? MBProductCardRenderContext.featured
        : MBProductCardRenderContext.grid;

    return Container(
      color: const Color(0xFFFFF7ED),
      child: Column(
        children: [
          _previewHeader(context, resolved),
          Expanded(
            child: Center(
              child: _PhonePreviewFrame(
                child: Center(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.symmetric(vertical: 24),
                    child: SizedBox(
                      width: cardWidth,
                      child: MBProductCardRenderer(
                        product: product,
                        contextType: previewContext,
                        onTap: () {},
                        onAddToCartTap: () {},
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _previewHeader(BuildContext context, MBResolvedCardConfig resolved) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(18, 16, 18, 14),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(
          bottom: BorderSide(color: Color(0xFFE5E7EB)),
        ),
      ),
      child: Row(
        children: [
          const Icon(Icons.smartphone_rounded, color: Color(0xFFF97316)),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              'Live Mobile Preview',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w900,
                  ),
            ),
          ),
          _pill(context, variant.id),
          const SizedBox(width: 8),
          _pill(context, resolved.footprint.label),
        ],
      ),
    );
  }

  Widget _pill(BuildContext context, String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF7ED),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: const Color(0xFFFED7AA)),
      ),
      child: Text(
        text,
        style: Theme.of(context).textTheme.labelSmall?.copyWith(
              color: const Color(0xFF9A3412),
              fontWeight: FontWeight.w900,
            ),
      ),
    );
  }

  double _cardWidthForFootprint(MBCardFootprint footprint) {
    switch (footprint) {
      case MBCardFootprint.halfWidth:
        return 170;
      case MBCardFootprint.fullWidth:
        return 320;
      case MBCardFootprint.twoByTwo:
        return 320;
    }
  }
}

class _PhonePreviewFrame extends StatelessWidget {
  const _PhonePreviewFrame({
    required this.child,
  });

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 365,
      height: 690,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF111827),
        borderRadius: BorderRadius.circular(42),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.22),
            blurRadius: 38,
            offset: const Offset(0, 18),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(32),
        child: DecoratedBox(
          decoration: const BoxDecoration(
            color: Color(0xFFFFF3EA),
          ),
          child: Stack(
            children: [
              Positioned.fill(child: child),
              Align(
                alignment: Alignment.topCenter,
                child: Container(
                  width: 110,
                  height: 22,
                  margin: const EdgeInsets.only(top: 0),
                  decoration: const BoxDecoration(
                    color: Color(0xFF111827),
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(18),
                      bottomRight: Radius.circular(18),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _EmptyStateCard extends StatelessWidget {
  const _EmptyStateCard({
    required this.title,
    required this.subtitle,
  });

  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0xFFE5E7EB)),
      ),
      child: Row(
        children: [
          const Icon(
            Icons.info_outline_rounded,
            color: Color(0xFFF97316),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w900,
                      ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: const Color(0xFF6B7280),
                      ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
