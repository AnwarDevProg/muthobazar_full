class InventoryBinding {}













