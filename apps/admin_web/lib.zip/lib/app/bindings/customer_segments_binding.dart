class CustomerSegmentsBinding {}













