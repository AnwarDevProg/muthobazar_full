class CategoriesBinding {}













