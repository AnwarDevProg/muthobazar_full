class ServiceCategoriesBinding {}













