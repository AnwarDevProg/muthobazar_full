class SlotsCapacityBinding {}













