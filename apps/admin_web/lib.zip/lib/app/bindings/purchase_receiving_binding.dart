class PurchaseReceivingBinding {}













