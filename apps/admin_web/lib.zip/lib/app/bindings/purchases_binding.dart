class PurchasesBinding {}













