class AdminAccessBinding {}













