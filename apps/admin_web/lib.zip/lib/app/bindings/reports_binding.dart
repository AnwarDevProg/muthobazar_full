class ReportsBinding {}













