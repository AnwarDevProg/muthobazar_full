class BrandsBinding {}













